/**
* @package Joomla
* @subpackage JoomShopping
* @author Dmitry Stashenko
* @website http://nevigen.com/
* @email support@nevigen.com
* @copyright Copyright © Nevigen.com. All rights reserved.
* @license Proprietary. Copyrighted Commercial Software
* @license agreement http://nevigen.com/license-agreement.html
**/
var dockbar = dockbar || {};
dockbar.show_overlay = function(){
	if (jQuery("#dockbar-overlay").size()>0) return;
	var div=jQuery("<div>").attr("id","dockbar-overlay");
	div.width(jQuery(window).width()+"px");
	div.height(jQuery(window).height()+"px");
	jQuery(document.body).append(div);
}
dockbar.hide_overlay = function(){
	jQuery("#dockbar-overlay").remove();
}
dockbar.show_bubble = function(elem_id) {
	dockbar.hide_bubble();
	var div=jQuery('<div>').attr('id','dockbar-bubble');
	div.html(dockbar.product_add_text);
	jQuery(document.body).append(div);
	var bottom_pos = jQuery('#fixblock').height() + 10;
	div.css({
			'position': 'fixed',
			'left': jQuery('#'+elem_id).position().left - div.width()/2 + 'px',
			'bottom': bottom_pos + div.height() + 110 + 'px'
			})
		.show()
		.animate(
			{
				bottom: bottom_pos
			},
			{
				duration: 'slow',
				easing: 'easeOutBounce'
			})
		.delay(3000)
		.fadeOut();
}
dockbar.hide_bubble = function(){
	jQuery('#dockbar-bubble').remove();
}
dockbar.show_fly = function(elem, target){
	target = jQuery('#dockbar_'+target);
	elem.clone().appendTo('body')
		.css({
			'position' : 'absolute',
			'z-index' : '10000',
			'left':elem.offset()['left'],
			'top':elem.offset()['top']
			})
		.animate({
			opacity: 0.5,
			left: target.offset()['left'],
			top: target.offset()['top'],
			width: 25
			},
			1000,
			function() {
			   jQuery(this).remove();
			});
}
dockbar.open = function(elem){
	dockbar.hide_bubble();
	jQuery(elem).addClass('current').siblings().removeClass('current');
	jQuery('#downslide_'+elem.id).show().siblings().hide();
	jQuery('#dockbar_down').css({'visibility':'visible'});
	jQuery('#downslide_dockbar').animate(
		{
			height: '200px'
		},
		{
			duration: 'fast',
			easing: 'linear'
		})
}
dockbar.close = function(elem){
	dockbar.hide_bubble();
	jQuery(elem).parent().children().removeClass('current');
	jQuery('#dockbar_down').css({'visibility':'hidden'});
	jQuery('#downslide_dockbar').animate(
		{
			height: '0px'
		},
		{
			duration: 'slow',
			easing: 'easeOutBounce'
		})
}
dockbar.toggle = function(elem){
	if (jQuery(elem).hasClass('current')) {
		dockbar.close(elem);
	} else {
		dockbar.open(elem);
	}
}
dockbar.carousel = function(elem){
    
	carouselInstance = jQuery(elem).touchCarousel({					
		pagingNav: false,
		snapToItems: false,
		itemsPerMove: 2,				
		scrollToLast: false,
		loopItems: false,
		scrollbar: true,
		autoplay: false
	}).data('touchCarousel');				
}
dockbar.cart_refresh = function(cart){
	jQuery('#downslide_dockbar_cart').html(cart['html']);
	jQuery('#count_cart_product').html(cart['count']).removeClass('emptyes').addClass('emptno');
	jQuery('#jshop_summ_product').html(cart['summ']);
	if (dockbar.cart_effect == 1) {
		dockbar.show_bubble('dockbar_cart');
	}
	var elem = jQuery('#count_cart_product');
	var position = elem.position();
	elem.clone()
		.css({'position' : 'absolute', 'z-index' : '100', 'top' : position.top+'px', 'left' : position.left+'px'})
		.appendTo("#dockbar_cart")
		.animate({fontSize: '+=30px', top: '-=15px',}, 500, function() {
			jQuery(this).animate({fontSize: '-=30px', top: '+=15px', opacity: '0'}, 500, function() {
				jQuery(this).remove();
			})
		});
	dockbar.carousel('#carousel-cart');
}
dockbar.wishlist_refresh = function(cart){
	jQuery('#downslide_dockbar_wishlist').html(cart['html']);
	var elem = jQuery('#dockbar_wishlist sub');
	elem.html('('+cart['count_item']+')').removeClass('sub-g').addClass('sub-r');
	if (dockbar.wishlist_effect == 1) {
		dockbar.show_bubble('dockbar_wishlist');
	}
	var position = elem.position();
	elem.clone()
		.css({'position' : 'absolute', 'z-index' : '100', 'top' : position.top+'px', 'left' : position.left+'px'})
		.appendTo('#dockbar_wishlist')
		.animate({fontSize: '+=30px', top: '-=15px',}, 500, function() {
			jQuery(this).animate({fontSize: '-=30px', top: '+=15px', opacity: '0'}, 500, function() {
				jQuery(this).remove();
			})
		});
	dockbar.carousel('#carousel-wishlist');
}
dockbar.compare_refresh = function(compare){
	jQuery('#downslide_dockbar_compare').html(compare['html']);
	var elem = jQuery('#dockbar_compare sub');
	elem.html('('+compare['count']+')').removeClass('sub-g').addClass('sub-r');
	if (dockbar.compare_effect == 1) {
		dockbar.show_bubble('dockbar_compare');
	}
	var position = elem.position();
	elem.clone()
		.css({'position' : 'absolute', 'z-index' : '100', 'top' : position.top+'px', 'left' : position.left+'px'})
		.appendTo('#dockbar_compare')
		.animate({fontSize: '+=30px', top: '-=15px',}, 500, function() {
			jQuery(this).animate({fontSize: '-=30px', top: '+=15px', opacity: '0'}, 500, function() {
				jQuery(this).remove();
			})
		});
	dockbar.carousel('#carousel-compare');
}
jQuery(function($){
	dockbar.carousel('#carousel-cart');
	dockbar.carousel('#carousel-wishlist');
	dockbar.carousel('#carousel-history');
	dockbar.carousel('#carousel-compare');
    $('.jshop_list_product .buttons a.button_buy').live('click', function(e){
		e.preventDefault();
		var a = $(this);
		$.ajax({
			type: "POST",
			url: a.attr('href'), 
			data : 'ajax=1',
			cache: false,  
			success: function(json){
				var cart = $.parseJSON(json);
				if (typeof cart[0] != 'undefined' && typeof cart[0].message != 'undefined') {
					var messages = new Array();
					var redirect_url;
					$.each(cart, function(key, cart_item){
						if(typeof cart_item.message != 'undefined' && cart_item.message.length > 0) {
							if(cart_item.code != 'redirect_url') {
								messages.push(cart_item.message);
							} else {
								redirect_url = cart_item.message;
							}
						}
					});
					if(messages.length > 0) {
						alert(messages.join(String.fromCharCode(10) + String.fromCharCode(13)));
					}
					if (redirect_url) {
						window.location.href = redirect_url;
					}
				} else if (typeof cart['html'] != 'undefined') {
					if (dockbar.cart_effect == 2) {
						dockbar.show_fly(a.closest('.block_product').find('img.jshop_img'),'cart');
					}
					dockbar.cart_refresh(cart);
				}
			}  
		});  
    });
	$('form[name=product]').submit(function(e) {
		e.preventDefault();
       //alert($(this).serialize());
		$.ajax({
			type: "POST",
			url: $(this).attr('action'), 
			data : $(this).serialize()+'&ajax=1',
			cache: false,  
			success: function(json){
				var cart = $.parseJSON(json);
				if(typeof cart[0] != 'undefined' && typeof cart[0].message != 'undefined') {
					var messages = new Array();
					$.each(cart, function(key, cart_item){
						if(typeof cart_item.message != 'undefined' && cart_item.message.length > 0) {
							if(cart_item.code != 'redirect_url') {
								messages.push(cart_item.message);
							}
						}
					});
					if(messages.length > 0) {
						alert(messages.join(String.fromCharCode(10) + String.fromCharCode(13)));
					}
				} else if (typeof cart['html'] != 'undefined') {
					if (cart['type']=='wishlist') {
						if (dockbar.wishlist_effect == 2) {
							dockbar.show_fly($('img[id^="main_image"]'),'wishlist');
						}
						dockbar.wishlist_refresh(cart);
					} else {
						if (dockbar.cart_effect == 2) {
							dockbar.show_fly($('img[id^="main_image"]'),'cart');
						}
						dockbar.cart_refresh(cart);
					}
				}
			}  
		});  
	});
    $('.add_to_compare a:first-child').live('click', function(e){
		e.preventDefault();
		var a = jQuery(this);
		$.ajax({
			type: "POST",
			url: $(this).attr('href'), 
			cache: false,  
			success: function(json){
				var compare = $.parseJSON(json);
				if (typeof compare['html'] != 'undefined') {
					a.hide().next().show();
					if (dockbar.compare_effect == 2) {
						var source = $('img[id^="main_image"]');
						if (!source.length) source = a.closest('.block_product').find('img.jshop_img');
						dockbar.show_fly(source,'compare');
					}
					dockbar.compare_refresh(compare);
				} else {
					alert(compare['msg']);
				}
			}  
		});  
    });
	$('#downslide_dockbar_callback form').submit(function(e){
		e.preventDefault();
		$('#downslide_dockbar_callback').empty().addClass('shopdockbar-wait');
		$.ajax({
			type: "POST",
			url: $(this).attr('action'), 
			data : $(this).serialize(),
			cache: false,  
			success: function(msg) {
				$('#downslide_dockbar_callback').removeClass('shopdockbar-wait').html(msg);
			}
		});
	})
	$('#downslide_dockbar_feedback form').submit(function(e){
		e.preventDefault();
		$('#downslide_dockbar_feedback').empty().addClass('shopdockbar-wait');
		$.ajax({
			type: "POST",
			url: $(this).attr('action'), 
			data : $(this).serialize(),
			cache: false,  
			success: function(msg) {
				$('#downslide_dockbar_feedback').removeClass('shopdockbar-wait').html(msg);
			}
		});
	})
});

(function(f){function q(b,c){var a,e;this.carouselRoot=f(b);var d=this;this._b=this._a=!1;this._e=this._d=this._c="";this._f;this._g;this._h;this._i;this._j;this._k=0;this.settings=f.extend({},f.fn.touchCarousel.defaults,c);this._l=this.carouselRoot.find(".touchcarousel-container");this._m=this._l[0].style;this._n=this._l.wrap(f('<div class="touchcarousel-wrapper" />')).parent();var g=this._l.find(".touchcarousel-item");this.items=[];this.numItems=g.length;a=navigator.userAgent.toLowerCase();e=/(chrome)[ \/]([\w.]+)/.exec(a)||
/(webkit)[ \/]([\w.]+)/.exec(a)||/(opera)(?:.*version|)[ \/]([\w.]+)/.exec(a)||/(msie) ([\w.]+)/.exec(a)||0>a.indexOf("compatible")&&/(mozilla)(?:.*? rv:([\w.]+)|)/.exec(a)||[];a=e[1]||"";e=e[2]||"0";var r={};a&&(r[a]=!0,r.version=e);r.chrome&&(r.webkit=!0);d._o=r;this._p;this._q=!1;this._t=this._s=this._r=0;this._w=this._v=this._u=!1;"ontouchstart"in window?(this.hasTouch=!0,this._c="touchstart.rs",this._d="touchmove.rs",this._e="touchend.rs",this._x=this.settings.baseTouchFriction):(this.hasTouch=
!1,this._x=this.settings.baseMouseFriction,this.settings.dragUsingMouse?(this._c="mousedown.rs",this._d="mousemove.rs",this._e="mouseup.rs",this._y,this._z,a=d._o,a.msie||a.opera?this._y=this._z="move":a.mozilla&&(this._y="-moz-grab",this._z="-moz-grabbing"),this._a1()):this._n.addClass("auto-cursor"));if((this.hasTouch||this.settings.useWebkit3d)&&"WebKitCSSMatrix"in window&&"m11"in new WebKitCSSMatrix)this._l.css({"-webkit-transform-origin":"0 0","-webkit-transform":"translateZ(0)"}),this._w=!0;
this._w?(this._b1="-webkit-transform",this._c1="translate3d(",this._d1="px, 0, 0)"):(this._b1="left",this._c1="",this._d1="px");this.hasTouch&&(this.settings.directionNavAutoHide=!1);this.settings.directionNav||(this._f1=this.settings.loopItems?this._e1=!0:this._e1=!1,this.settings.loopItems=!0);var p,h,n=0;g.eq(this.numItems-1).addClass("last");g.each(function(b){h=f(this);p={};p.item=h;p.index=b;p.posX=n;p.width=h.outerWidth(!0)||d.settings.itemFallbackWidth;n+=p.width;if(this.hasTouch){var a;h.find("a").each(function(){a=
f(this);a.data("tc-href",a.attr("href"));a.data("tc-target",a.attr("target"));a.attr("href","#");a.bind("click",function(a){a.preventDefault();if(d._q)return!1;a=f(this).data("tc-href");var b=f(this).data("tc-target");!b||"_g1"===b.toLowerCase()?window.location.href=a:window.open(a)})})}else h.find("a").bind("click.touchcarousel",function(a){if(d._q)return a.preventDefault(),!1});h.find(".non-draggable").bind(d._c,function(a){d._q=!1;a.stopImmediatePropagation()});d.items.push(p)});this._h1=this._f=
n;this._i1=0<this.settings.itemsPerMove?this.settings.itemsPerMove:1;if(this.settings.pagingNav){if(this._j1=this.settings.snapToItems=!0,this._k1=Math.ceil(this.numItems/this._i1),this._l1=0,this.settings.pagingNavControls){this._m1=f('<div class="tc-paging-container"><div class="tc-paging-centerer"><div class="tc-paging-centerer-inside"></div></div></div>');g=this._m1.find(".tc-paging-centerer-inside");for(e=1;e<=this._k1;e++)a=f('<a class="tc-paging-item" href="#">'+e+"</a>").data("tc-id",e),e===
this._l1+1&&a.addClass("current"),g.append(a);this._n1=g.find(".tc-paging-item").click(function(a){a.preventDefault();d.goTo((f(a.currentTarget).data("tc-id")-1)*d._i1)});this._n.after(this._m1)}}else this._j1=!1;this._l.css({width:n});this.settings.directionNav&&(this._n.after("<a href='#' class='arrow-holder left'><span class='arrow-icon left'></span></a> <a href='#' class='arrow-holder right'><span class='arrow-icon right'></span></a>"),this.arrowLeft=this.carouselRoot.find(".arrow-holder.left"),
this.arrowRight=this.carouselRoot.find(".arrow-holder.right"),1>this.arrowLeft.length||1>this.arrowRight.length?this.settings.directionNav=!1:this.settings.directionNavAutoHide&&(this.arrowLeft.hide(),this.arrowRight.hide(),this.carouselRoot.one("mousemove.arrowshover",function(){d.arrowLeft.fadeIn("fast");d.arrowRight.fadeIn("fast")}),this.carouselRoot.hover(function(){d.arrowLeft.fadeIn("fast");d.arrowRight.fadeIn("fast")},function(){d.arrowLeft.fadeOut("fast");d.arrowRight.fadeOut("fast")})),this._p1(0),
this.settings.directionNav&&(this.arrowRight.click(function(a){a.preventDefault();(d.settings.loopItems&&!d._u||!d._f1)&&d.next()}),this.arrowLeft.click(function(a){a.preventDefault();(d.settings.loopItems&&!d._u||!d._e1)&&d.prev()})));this.carouselWidth;this._q1="onorientationchange"in window?"orientationchange.touchcarousel":"resize.touchcarousel";var l;f(window).bind(this._q1,function(){l&&clearTimeout(l);l=setTimeout(function(){d.updateCarouselSize(!1)},100)});this.settings.scrollbar?(this._r1=
f("<div class='scrollbar-holder'><div class='scrollbar"+("light"===this.settings.scrollbarTheme.toLowerCase()?" light":" dark")+"'></div></div>"),this._r1.appendTo(this.carouselRoot),this.scrollbarJQ=this._r1.find(".scrollbar"),this._s1="",this._t1=this.scrollbarJQ[0].style,this._u1=0,this.settings.scrollbarAutoHide?(this._v1=!1,this.scrollbarJQ.css("opacity",0)):this._v1=!0):this.settings.scrollbarAutoHide=!1;this.updateCarouselSize(!0);this._n.bind(this._c,function(a){d._w1(a)});this.settings.autoplay&&
0<this.settings.autoplayDelay?(this._x1=!1,this.autoplayTimer="",this.wasAutoplayRunning=!0,this.hasTouch||this.carouselRoot.hover(function(){d._x1=!0;d._y1()},function(){d._x1=!1;d._z1()}),this.autoplay=!0,this._a2()):this.autoplay=!1;this.settings.keyboardNav&&f(document).bind("keydown.touchcarousel",function(a){d._u||(37===a.keyCode?d.prev():39===a.keyCode&&d.next())});this.carouselRoot.css("overflow","visible")}q.prototype={goTo:function(b,c){var a=this.items[b];a&&(!c&&(this.autoplay&&this.settings.autoplayStopAtAction)&&
this.stopAutoplay(),this._b2(b),this.endPos=this._c2(),a=-a.posX,0<a?a=0:a<this.carouselWidth-this._h1&&(a=this.carouselWidth-this._h1),this.animateTo(a,this.settings.transitionSpeed,"easeInOutSine"))},next:function(b){var c=this._c2(),a=this._d2(c).index;this._j1?(c=this._l1+1,a=c>this._k1-1?this.settings.loopItems?0:(this._k1-1)*this._i1:c*this._i1):(a+=this._i1,this.settings.loopItems&&c<=this.carouselWidth-this._h1&&(a=0),a>this.numItems-1&&(a=this.numItems-1));this.goTo(a,b)},prev:function(b){var c=
this._c2(),a=this._d2(c).index;this._j1?(c=this._l1-1,a=0>c?this.settings.loopItems?(this._k1-1)*this._i1:0:c*this._i1):(a-=this._i1,0>a&&(a=this.settings.loopItems?0>c?0:this.numItems-1:0));this.goTo(a,b)},getCurrentId:function(){return this._d2(this._c2()).index},setXPos:function(b,c){c?this._t1[this._b1]=this._c1+b+this._d1:this._m[this._b1]=this._c1+b+this._d1},stopAutoplay:function(){this._y1();this.wasAutoplayRunning=this.autoplay=!1},resumeAutoplay:function(){this.autoplay=!0;this.wasAutoplayRunning||
this._z1()},updateCarouselSize:function(b){this.carouselWidth=this.carouselRoot.width();if(this.settings.scrollToLast){var c=0;if(this._j1){var a=this.numItems%this._i1;if(0<a)for(a=this.numItems-a;a<this.numItems;a++)c+=this.items[a].width;else c=this.carouselWidth}else c=this.items[this.numItems-1].width;this._h1=this._f+this.carouselWidth-c}else this._h1=this._f;this.settings.scrollbar&&(c=Math.round(this._r1.width()/(this._h1/this.carouselWidth)),this.scrollbarJQ.css("width",c),this._u1=this._r1.width()-
c);if(!this.settings.scrollToLast){if(this.carouselWidth>=this._f){this._v=!0;this.settings.loopItems||(this._f1=!0,this.arrowRight.addClass("disabled"),this._e1=!0,this.arrowLeft.addClass("disabled"));this.setXPos(0);return}this._v&&(this._e1=this._f1=this._v=!1,this.arrowRight.removeClass("disabled"),this.arrowLeft.removeClass("disabled"))}b||(b=this.endPos=this._c2(),0<b?b=0:b<this.carouselWidth-this._h1&&(b=this.carouselWidth-this._h1),this.animateTo(b,300,"easeInOutSine"))},animateTo:function(b,
c,a,e,d,g,r){function p(){h._b=!1;h._a2();h.settings.scrollbarAutoHide&&h._g2();null!==h.settings.onAnimComplete&&h.settings.onAnimComplete.call(h)}null!==this.settings.onAnimStart&&this.settings.onAnimStart.call(this);this.autoplay&&this.autoplayTimer&&(this.wasAutoplayRunning=!0,this._y1());this._e2();var h=this,n=this.settings.scrollbar,l=h._b1,j=h._c1,m=h._d1,q={containerPos:this.endPos},k={containerPos:b},v={containerPos:d};d=e?d:b;var s=h._m;h._b=!0;if(n){var t=this._t1,u=h._h1-h.carouselWidth;
this.settings.scrollbarAutoHide&&(this._v1||this._f2())}this._p1(d);this._p=f(q).animate(k,{duration:c,easing:a,step:function(){n&&(t[l]=j+Math.round(h._u1*(-this.containerPos/u))+m);s[l]=j+Math.round(this.containerPos)+m},complete:function(){e?h._p=f(k).animate(v,{duration:g,easing:r,step:function(){n&&(t[l]=j+Math.round(h._u1*(-this.containerPos/u))+m);s[l]=j+Math.round(this.containerPos)+m},complete:function(){n&&(t[l]=j+Math.round(h._u1*(-v.containerPos/u))+m);s[l]=j+Math.round(v.containerPos)+
m;p()}}):(n&&(t[l]=j+Math.round(h._u1*(-k.containerPos/u))+m),s[l]=j+Math.round(k.containerPos)+m,p())}})},destroy:function(){this.stopAutoplay();this._n.unbind(this._c);f(document).unbind(this._d).unbind(this._e);f(window).unbind(this._q1);this.settings.keyboardNav&&f(document).unbind("keydown.touchcarousel");this.carouselRoot.remove()},_b2:function(b){this._j1&&(this._l1=b=this._h2(b),this.settings.pagingNavControls&&(this._n1.removeClass("current"),this._n1.eq(b).addClass("current")))},_h2:function(b){for(var c=
this._i1,a=0;a<this._k1;a++)if(b>=a*c&&b<a*c+c)return a;return 0>b?0:b>=this._k1?this._k1-1:!1},_i2:function(){this.settings.loopItems||(this._e1?(this._e1=!1,this.arrowLeft.removeClass("disabled")):this._f1&&(this._f1=!1,this.arrowRight.removeClass("disabled")))},_o1:function(){!this._e1&&!this.settings.loopItems&&(this._e1=!0,this.arrowLeft.addClass("disabled"),this._f1&&(this._f1=!1,this.arrowRight.removeClass("disabled")))},_j2:function(){!this._f1&&!this.settings.loopItems&&(this._f1=!0,this.arrowRight.addClass("disabled"),
this._e1&&(this._e1=!1,this.arrowLeft.removeClass("disabled")))},_d2:function(b){b=-b;for(var c,a=0;a<this.numItems;a++)if(c=this.items[a],b>=c.posX&&b<c.posX+c.width)return c;return-1},_a2:function(){this.autoplay&&this.wasAutoplayRunning&&(this._x1||this._z1(),this.wasAutoplayRunning=!1)},_g2:function(){var b=this;this._v1=!1;this._s1&&clearTimeout(this._s1);this._s1=setTimeout(function(){b.scrollbarJQ.animate({opacity:0},150,"linear")},450)},_f2:function(){this._v1=!0;this._s1&&clearTimeout(this._s1);
this.scrollbarJQ.stop().animate({opacity:1},150,"linear")},_e2:function(){this._p&&this._p.stop()},_z1:function(){if(this.autoplay){var b=this;this.autoplayTimer||(this.autoplayTimer=setInterval(function(){!b._k2&&!b._b&&b.next(!0)},this.settings.autoplayDelay))}},_y1:function(){this.autoplayTimer&&(clearInterval(this.autoplayTimer),this.autoplayTimer="")},_c2:function(b){b=!b?this._l:this.scrollbarJQ;return this._w?(b=b.css("-webkit-transform").replace(/^matrix\(/i,"").split(/, |\)$/g),parseInt(b[4],
10)):Math.round(b.position().left)},_w1:function(b){if(!this._k2){this.autoplay&&this.settings.autoplayStopAtAction&&this.stopAutoplay();this._e2();this.settings.scrollbarAutoHide&&this._f2();var c;if(this.hasTouch)if(this._a=!1,(c=b.originalEvent.touches)&&0<c.length)c=c[0];else return!1;else c=b,b.preventDefault();this._l2();this._k2=!0;var a=this;this._w&&a._l.css({"-webkit-transition-duration":"0","-webkit-transition-property":"none"});f(document).bind(this._d,function(b){a._m2(b)});f(document).bind(this._e,
function(b){a._n2(b)});this._o2=this._c2();this._i=c.clientX;this._q=!1;this._k=b.timeStamp||(new Date).getTime();this._t=0;this._s=this._r=c.clientX;this._p2=c.clientY}},_m2:function(b){var c=b.timeStamp||(new Date).getTime(),a;if(this.hasTouch){if(this._a)return!1;a=b.originalEvent.touches;if(1<a.length)return!1;a=a[0];if(Math.abs(a.clientY-this._p2)>Math.abs(a.clientX-this._r)+3)return this.settings.lockAxis&&(this._a=!0),!1}else a=b;b.preventDefault();this._j=a.clientX;this._q2=this._r2;b=a.clientX-
this._s;this._q2!=b&&(this._r2=b);if(0!=b){var e=this._o2+this._t;0<=e?(b/=4,this._o1()):e<=this.carouselWidth-this._h1?(this._j2(),b/=4):this._i2();this._t+=b;this.setXPos(e);this.settings.scrollbar&&this.setXPos(this._u1*(-e/(this._h1-this.carouselWidth)),!0)}this._s=a.clientX;350<c-this._k&&(this._k=c,this._i=a.clientX);null!==this.settings.onDragStart&&this.settings.onDragStart.call(this);return!1},_n2:function(b){if(this._k2){var c=this;this._k2=!1;this._a1();this.endPos=this._c2();this.isdrag=
!1;f(document).unbind(this._d).unbind(this._e);if(this.endPos==this._o2){this._q=!1;this.settings.scrollbarAutoHide&&this._g2();return}this._q=!0;var a=this._j-this._i;b=Math.max(40,(b.timeStamp||(new Date).getTime())-this._k);var e=0.5;b=Math.abs(a)/b;var d=function(a){0<a?a=0:a<c.carouselWidth-c._h1&&(a=c.carouselWidth-c._h1);return a};if(this.settings.snapToItems){this.autoplay&&this.settings.autoplayStopAtAction&&this.stopAutoplay();var a=Boolean(0<this._r-this._s),e=d(this._c2()),g=this._d2(e).index;
this._j1?(a&&(e=Math.max(e-this.carouselWidth-1,1-c._h1),g=this._d2(e).index,void 0===g&&(g=this.numItems-1)),g=this._h2(g)*this._i1):g+=a?this._i1:-this._i1+1;g=a?Math.min(g,this.numItems-1):Math.max(g,0);e=this.items[g];this._b2(g);e&&(e=d(-e.posX),d=Math.abs(this.endPos-e),b=Math.max(1.08*d/b,150),g=Boolean(180>b),d*=0.08,a&&(d*=-1),this.animateTo(g?e+d:e,Math.min(b,400),"easeOutSine",g,e,300,"easeOutCubic"))}else d=0,2>=b?(e=3.5*this._x,d=0):2<b&&3>=b?(e=4*this._x,d=200):3<b&&(d=300,4<b&&(b=4,
d=400,e=6*this._x),e=5*this._x),a=2*b*b/(2*e)*(0>a?-1:1),e=2*b/e+d,0<this.endPos+a?0<this.endPos?this.animateTo(0,800,"easeOutCubic"):this.animateTo(this.carouselWidth/10*((d+200)/1E3),1.1*Math.abs(this.endPos)/b,"easeOutSine",!0,0,400,"easeOutCubic"):this.endPos+a<this.carouselWidth-this._h1?this.endPos<this.carouselWidth-this._h1?this.animateTo(this.carouselWidth-this._h1,800,"easeOutCubic"):this.animateTo(this.carouselWidth-this._h1-this.carouselWidth/10*((d+200)/1E3),1.1*Math.abs(this.carouselWidth-
this._h1-this.endPos)/b,"easeOutSine",!0,this.carouselWidth-this._h1,400,"easeOutCubic"):this.animateTo(this.endPos+a,e,"easeOutCubic");null!==this.settings.onDragRelease&&this.settings.onDragRelease.call(this)}return!1},_p1:function(b){void 0===b&&(b=this._c2());this.settings.loopItems||(0<=b?this._o1():b<=this.carouselWidth-this._h1?this._j2():this._i2())},_a1:function(){this._y?this._n.css("cursor",this._y):(this._n.removeClass("grabbing-cursor"),this._n.addClass("grab-cursor"))},_l2:function(){this._z?
this._n.css("cursor",this._z):(this._n.removeClass("grab-cursor"),this._n.addClass("grabbing-cursor"))}};f.fn.touchCarousel=function(b){return this.each(function(){var c=new q(f(this),b);f(this).data("touchCarousel",c)})};f.fn.touchCarousel.defaults={itemsPerMove:1,snapToItems:!1,pagingNav:!1,pagingNavControls:!0,autoplay:!1,autoplayDelay:3E3,autoplayStopAtAction:!0,scrollbar:!0,scrollbarAutoHide:!1,scrollbarTheme:"dark",transitionSpeed:600,directionNav:!0,directionNavAutoHide:!1,loopItems:!1,keyboardNav:!1,
dragUsingMouse:!0,scrollToLast:!1,itemFallbackWidth:500,baseMouseFriction:0.0012,baseTouchFriction:8E-4,lockAxis:!0,useWebkit3d:!1,onAnimStart:null,onAnimComplete:null,onDragStart:null,onDragRelease:null};f.fn.touchCarousel.settings={};})(jQuery);
(function(){if(navigator.userAgent.match(/OS 6(_\d)+/i)&&void 0===window.getTimeouts){var f={},q={},b=window.setTimeout,c=window.setInterval,a=window.clearTimeout,e=window.clearInterval,d=function(a,d,e,g){if(e){var l=function(){var a=(new Date).getTime();!1!==k[j].loop?(k[j].requestededFrame=webkitRequestAnimationFrame(l),k[j].loop=a<=m):(k[j].callback&&k[j].callback(),w?(m=(new Date).getTime()+d,k[j].loop=a<=m,k[j].requestedFrame=webkitRequestAnimationFrame(l)):delete k[j])},j;e=a.name||"rafTimer"+
Math.floor(1E3*Math.random());var m=(new Date).getTime()+d,w=g||!1,k=w?q:f;j=e+""+m;k[j]={};k[j].loop=!0;k[j].callback=a;l();return j}return g?c(a,d):b(a,d)},g=function(b,d){if(b.indexOf&&-1<b.indexOf("rafTimer")){var c;c=d?q:f;c[b]?(c[b].callback=void 0,c[b].loop=!1,c=!0):c=!1;return c}return d?e(b):a(b)};window.getTimeouts=function(){return{timeouts:f,intervals:q}};window.setTimeout=function(a,b){return d(a,b,!0)};window.setInterval=function(a,b){return d(a,b,!0,!0)};window.clearTimeout=function(a){return g(a)};
window.clearInterval=function(a){return g(a,!0)}}})();

jQuery.easing.jswing=jQuery.easing.swing,jQuery.extend(jQuery.easing,{def:"easeOutQuad",swing:function(a,b,c,d,e){return jQuery.easing[jQuery.easing.def](a,b,c,d,e)},easeInQuad:function(a,b,c,d,e){return d*(b/=e)*b+c},easeOutQuad:function(a,b,c,d,e){return-d*(b/=e)*(b-2)+c},easeInOutQuad:function(a,b,c,d,e){return(b/=e/2)<1?d/2*b*b+c:-d/2*(--b*(b-2)-1)+c},easeInCubic:function(a,b,c,d,e){return d*(b/=e)*b*b+c},easeOutCubic:function(a,b,c,d,e){return d*((b=b/e-1)*b*b+1)+c},easeInOutCubic:function(a,b,c,d,e){return(b/=e/2)<1?d/2*b*b*b+c:d/2*((b-=2)*b*b+2)+c},easeInQuart:function(a,b,c,d,e){return d*(b/=e)*b*b*b+c},easeOutQuart:function(a,b,c,d,e){return-d*((b=b/e-1)*b*b*b-1)+c},easeInOutQuart:function(a,b,c,d,e){return(b/=e/2)<1?d/2*b*b*b*b+c:-d/2*((b-=2)*b*b*b-2)+c},easeInQuint:function(a,b,c,d,e){return d*(b/=e)*b*b*b*b+c},easeOutQuint:function(a,b,c,d,e){return d*((b=b/e-1)*b*b*b*b+1)+c},easeInOutQuint:function(a,b,c,d,e){return(b/=e/2)<1?d/2*b*b*b*b*b+c:d/2*((b-=2)*b*b*b*b+2)+c},easeInSine:function(a,b,c,d,e){return-d*Math.cos(b/e*(Math.PI/2))+d+c},easeOutSine:function(a,b,c,d,e){return d*Math.sin(b/e*(Math.PI/2))+c},easeInOutSine:function(a,b,c,d,e){return-d/2*(Math.cos(Math.PI*b/e)-1)+c},easeInExpo:function(a,b,c,d,e){return b==0?c:d*Math.pow(2,10*(b/e-1))+c},easeOutExpo:function(a,b,c,d,e){return b==e?c+d:d*(-Math.pow(2,-10*b/e)+1)+c},easeInOutExpo:function(a,b,c,d,e){return b==0?c:b==e?c+d:(b/=e/2)<1?d/2*Math.pow(2,10*(b-1))+c:d/2*(-Math.pow(2,-10*--b)+2)+c},easeInCirc:function(a,b,c,d,e){return-d*(Math.sqrt(1-(b/=e)*b)-1)+c},easeOutCirc:function(a,b,c,d,e){return d*Math.sqrt(1-(b=b/e-1)*b)+c},easeInOutCirc:function(a,b,c,d,e){return(b/=e/2)<1?-d/2*(Math.sqrt(1-b*b)-1)+c:d/2*(Math.sqrt(1-(b-=2)*b)+1)+c},easeInElastic:function(a,b,c,d,e){var f=1.70158,g=0,h=d;if(b==0)return c;if((b/=e)==1)return c+d;g||(g=e*.3);if(h<Math.abs(d)){h=d;var f=g/4}else var f=g/(2*Math.PI)*Math.asin(d/h);return-(h*Math.pow(2,10*(b-=1))*Math.sin((b*e-f)*2*Math.PI/g))+c},easeOutElastic:function(a,b,c,d,e){var f=1.70158,g=0,h=d;if(b==0)return c;if((b/=e)==1)return c+d;g||(g=e*.3);if(h<Math.abs(d)){h=d;var f=g/4}else var f=g/(2*Math.PI)*Math.asin(d/h);return h*Math.pow(2,-10*b)*Math.sin((b*e-f)*2*Math.PI/g)+d+c},easeInOutElastic:function(a,b,c,d,e){var f=1.70158,g=0,h=d;if(b==0)return c;if((b/=e/2)==2)return c+d;g||(g=e*.3*1.5);if(h<Math.abs(d)){h=d;var f=g/4}else var f=g/(2*Math.PI)*Math.asin(d/h);return b<1?-0.5*h*Math.pow(2,10*(b-=1))*Math.sin((b*e-f)*2*Math.PI/g)+c:h*Math.pow(2,-10*(b-=1))*Math.sin((b*e-f)*2*Math.PI/g)*.5+d+c},easeInBack:function(a,b,c,d,e,f){return f==undefined&&(f=1.70158),d*(b/=e)*b*((f+1)*b-f)+c},easeOutBack:function(a,b,c,d,e,f){return f==undefined&&(f=1.70158),d*((b=b/e-1)*b*((f+1)*b+f)+1)+c},easeInOutBack:function(a,b,c,d,e,f){return f==undefined&&(f=1.70158),(b/=e/2)<1?d/2*b*b*(((f*=1.525)+1)*b-f)+c:d/2*((b-=2)*b*(((f*=1.525)+1)*b+f)+2)+c},easeInBounce:function(a,b,c,d,e){return d-jQuery.easing.easeOutBounce(a,e-b,0,d,e)+c},easeOutBounce:function(a,b,c,d,e){return(b/=e)<1/2.75?d*7.5625*b*b+c:b<2/2.75?d*(7.5625*(b-=1.5/2.75)*b+.75)+c:b<2.5/2.75?d*(7.5625*(b-=2.25/2.75)*b+.9375)+c:d*(7.5625*(b-=2.625/2.75)*b+.984375)+c},easeInOutBounce:function(a,b,c,d,e){return b<e/2?jQuery.easing.easeInBounce(a,b*2,0,d,e)*.5+c:jQuery.easing.easeOutBounce(a,b*2-e,0,d,e)*.5+d*.5+c}});


 jQuery(document).ready(function(){
              
              if(jQuery("div").is(".attributes_10")){
                jQuery(".buy").prop('disabled', true);
              }
              
              var mas = new Array()

              

             
           
             mas[jQuery("#i"+jQuery("#jshop_attr_id10 option:selected").val()+"").attr("value1")]=jQuery("#i"+jQuery("#jshop_attr_id10 option:selected").val()+"").attr("value2");
             jQuery("input[name='freeattribut[2]']").parent("span").parent("div").css("display", "none");
             jQuery("input[name='freeattribut[3]']").parent("span").parent("div").css("display", "none");
             jQuery("input[name='freeattribut[3]']").val("");jQuery("input[name='freeattribut[2]']").val("");  
              var cnt=11;   
             // alert(jQuery("#jshop_attr_id10 :selected").val());
              
               if( mas[jQuery("#i"+jQuery("#jshop_attr_id10 option:selected").val()+"").attr("value1")]=="[C]"){
                  cnt=11;
                  jQuery("input[name='freeattribut[2]']").parent("span").parent("div").css("display", "block");
                  jQuery("input[name='freeattribut[3]']").parent("span").parent("div").css("display", "none");  
                  jQuery("input[name='freeattribut[3]']").val("");
                }
                if( mas[jQuery("#i"+jQuery("#jshop_attr_id10 option:selected").val()+"").attr("value1")]=="[S]"){
                    
                  cnt=15;
                  jQuery("input[name='freeattribut[3]']").parent("span").parent("div").css("display", "block");
                  jQuery("input[name='freeattribut[2]']").parent("span").parent("div").css("display", "none");
                  jQuery("input[name='freeattribut[2]']").val("");  
                }
                if( mas[jQuery("#i"+jQuery("#jshop_attr_id10 option:selected").val()+"").attr("value1")]=="[S10]"){
                  cnt=10;
                  jQuery("input[name='freeattribut[3]']").parent("span").parent("div").css("display", "block");
                  jQuery("input[name='freeattribut[2]']").parent("span").parent("div").css("display", "none");
                  jQuery("input[name='freeattribut[2]']").val("");  
                }
                if( mas[jQuery("#i"+jQuery("#jshop_attr_id10 option:selected").val()+"").attr("value1")]=="[S10 C]"){
                   cnt=-1;
                   jQuery("input[name='freeattribut[3]']").parent("span").parent("div").css("display", "block");
                   jQuery("input[name='freeattribut[2]']").parent("span").parent("div").css("display", "block");
                }
                if( mas[jQuery("#i"+jQuery("#jshop_attr_id10 option:selected").val()+"").attr("value1")]=="[SC]"){
                    
                    cnt=0;
                   jQuery("input[name='freeattribut[3]']").parent("span").parent("div").css("display", "block");
                   jQuery("input[name='freeattribut[2]']").parent("span").parent("div").css("display", "block");
                }
             
             
             
            
                

           
             jQuery("#jshop_attr_id10").change(function(){
                mas[jQuery("#i"+jQuery("#jshop_attr_id10 option:selected").val()+"").attr("value1")]=jQuery("#i"+jQuery("#jshop_attr_id10 option:selected").val()+"").attr("value2");
                
                
             
                
                if( mas[jQuery("#i"+jQuery("#jshop_attr_id10 option:selected").val()+"").attr("value1")]=="[C]"){
                  cnt=11;
                  jQuery("input[name='freeattribut[2]']").parent("span").parent("div").css("display", "block");
                  jQuery("input[name='freeattribut[3]']").parent("span").parent("div").css("display", "none");  
                  jQuery("input[name='freeattribut[3]']").val("");
                }
                if( mas[jQuery("#i"+jQuery("#jshop_attr_id10 option:selected").val()+"").attr("value1")]=="[S]"){
                    
                  cnt=15;
                  jQuery("input[name='freeattribut[3]']").parent("span").parent("div").css("display", "block");
                  jQuery("input[name='freeattribut[2]']").parent("span").parent("div").css("display", "none");
                  jQuery("input[name='freeattribut[2]']").val("");  
                }
                if( mas[jQuery("#i"+jQuery("#jshop_attr_id10 option:selected").val()+"").attr("value1")]=="[S10]"){
                  cnt=10;
                  jQuery("input[name='freeattribut[3]']").parent("span").parent("div").css("display", "block");
                  jQuery("input[name='freeattribut[2]']").parent("span").parent("div").css("display", "none");
                  jQuery("input[name='freeattribut[2]']").val("");  
                }
                if( mas[jQuery("#i"+jQuery("#jshop_attr_id10 option:selected").val()+"").attr("value1")]=="[SC]"){
                   
                   cnt=0;
                   jQuery("input[name='freeattribut[3]']").parent("span").parent("div").css("display", "block");
                   jQuery("input[name='freeattribut[2]']").parent("span").parent("div").css("display", "block");
                }
                if( mas[jQuery("#i"+jQuery("#jshop_attr_id10 option:selected").val()+"").attr("value1")]=="[S10 C]"){
                   cnt=-1;
                   jQuery("input[name='freeattribut[3]']").parent("span").parent("div").css("display", "block");
                   jQuery("input[name='freeattribut[2]']").parent("span").parent("div").css("display", "block");
                }
             }); 
            
             jQuery("input[name='freeattribut[2]']").keyup(function(key){
                var str=""+jQuery("input[name='freeattribut[2]']").val();
                str2=str.toUpperCase();
                str=str2;
                jQuery("input[name='freeattribut[2]']").val(str);
                if(cnt==0){
                    if(str.length<11){jQuery(".buy").prop('disabled', true);}
                    if(str.length>=11){
                        str2=str.substring(0, 11);
                        jQuery("input[name='freeattribut[2]']").val(str2);
                        jQuery(".buy").prop('disabled', false);
                    }
                }else{
                    if(cnt==-1){
                        if(str.length<11){jQuery(".buy").prop('disabled', true);}
                        if(str.length>=11){
                            str2=str.substring(0, 11);
                            jQuery("input[name='freeattribut[2]']").val(str2);
                            jQuery(".buy").prop('disabled', false);
                        }
                    }else{
                        if(str.length<cnt){jQuery(".buy").prop('disabled', true);}
                        if(str.length>=cnt){
                            str2=str.substring(0, cnt);
                            jQuery("input[name='freeattribut[2]']").val(str2);
                            jQuery(".buy").prop('disabled', false);
                        }
                    }
                }
             });
            
            jQuery("input[name='freeattribut[2]']").keypress(function(key){
            if(((key.charCode >= 48 && key.charCode <= 57) || (key.charCode >= 65 && key.charCode <= 90)) || (key.charCode >= 97 && key.charCode <= 122)){
            }else{
                return false;
            }
            });
            
            jQuery("input[name='freeattribut[3]']").keyup(function(key){
                var str=""+jQuery("input[name='freeattribut[3]']").val();
                str2=str.toUpperCase();
                str=str2;
                jQuery("input[name='freeattribut[3]']").val(str);
                if(cnt==0){
                    if(str.length<15){jQuery(".buy").prop('disabled', true);}
                    if(str.length>=15){
                        str2=str.substring(0, 15);
                        jQuery("input[name='freeattribut[3]']").val(str2);
                        jQuery(".buy").prop('disabled', false);
                    }
                }else{
                    if(cnt==-1){
                        if(str.length<10){jQuery(".buy").prop('disabled', true);}
                      if(str.length>=10){
                            str2=str.substring(0, 10);
                            jQuery("input[name='freeattribut[3]']").val(str2);
                            jQuery(".buy").prop('disabled', false);
                        }  
                    }
                    else{
                        if(str.length<cnt){jQuery(".buy").prop('disabled', true);}
                    if(str.length>=cnt){
                        str2=str.substring(0, cnt);
                        jQuery("input[name='freeattribut[3]']").val(str2);
                        jQuery(".buy").prop('disabled', false);
                    }
                    }
                }
            });
            
            jQuery("input[name='freeattribut[3]']").keypress(function(key){
            if(((key.charCode >= 48 && key.charCode <= 57) || (key.charCode >= 65 && key.charCode <= 90)) || (key.charCode >= 97 && key.charCode <= 122)){
            }else{
                return false;
            }
            });
            
        });